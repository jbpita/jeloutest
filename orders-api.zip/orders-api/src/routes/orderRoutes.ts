import { Router } from 'express'
import { OrdersRepository } from '../core/adapters/OrdersRepository'
import { CreateOrderUseCase } from '../core/useCases/CreateOrderUseCase'
import { ConfirmOrderUseCase } from '../core/useCases/ConfirmOrderUseCase'

const router = Router()
const repo = new OrdersRepository()
const createUC = new CreateOrderUseCase(repo)
const confirmUC = new ConfirmOrderUseCase(repo)

router.post('/orders', async (req, res, next) => {
    try {
        const created = await createUC.execute(req.body)
        res.status(201).json(created)
    } catch (e) {
        next(e)
    }
})

router.post('/orders/:id/confirm', async (req, res, next) => {
    try {
        const id = Number(req.params.id)
        const result = await confirmUC.execute(id)
        res.json(result)
    } catch (e) { 
        next(e) 
    }
})

export default router
