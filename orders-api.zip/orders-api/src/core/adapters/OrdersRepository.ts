import { getDB } from '../../infra/dbClient'
import { IOrdersRepository, CreateOrderInput, CreatedOrder } from '../../core/ports/IordersRepository'
import { ProductsRepository } from './ProductsRepository'

export class OrdersRepository implements IOrdersRepository {
  
    private products = new ProductsRepository()

    async createOrder(input: CreateOrderInput): Promise<CreatedOrder> {
        
        const db = await getDB()
        const conn = await db.getConnection()

        try {

            await conn.query("SET TRANSACTION ISOLATION LEVEL READ COMMITTED");
            await conn.beginTransaction()

            const [ordRes]: any = await conn.query(
                "INSERT INTO orders (customer_id, status, total_cents) VALUES (?, 'CREATED', 0)",
                [input.customer_id]
            )
            const orderId = ordRes.insertId

            let total = 0

            for (const it of input.items) {
                const price = await this.products.getUnitPriceCents(it.product_id)
                const ok = await this.products.hasStock(it.product_id, it.qty)
               
                if (!ok) throw new Error(`Insufficient stock: product ${it.product_id}`)

                const subtotal = price * it.qty
                total += subtotal

                await conn.query(
                    'INSERT INTO order_items (order_id, product_id, qty, unit_price_cents, subtotal_cents) VALUES (?, ?, ?, ?, ?)',
                    [orderId, it.product_id, it.qty, price, subtotal]
                )
                
                await this.products.decStock(it.product_id, it.qty)
            }

            await conn.query('UPDATE orders SET total_cents = ? WHERE id = ?', [total, orderId])
            
            await conn.commit()

            return { id: orderId, status: 'CREATED', total_cents: total }
        
        } catch (e) {
            await conn.rollback()
            console.error('❌ Transaction rolled back due to: ', e)
            throw e
        } finally {
            conn.release()
        }
    }

    async confirmOrder(orderId: number) {
        const db = await getDB()
        await db.query("UPDATE orders SET status = 'CONFIRMED' WHERE id = ? AND status = 'CREATED'", [orderId])
        const [rows]: any = await db.query('SELECT id, status, total_cents FROM orders WHERE id = ?', [orderId])
        if (!rows[0]) throw new Error('Order not found')
        return rows[0]
    }
}
