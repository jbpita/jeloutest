export interface OrderItemInput {
  product_id: number;
  qty: number;
}

export interface CreateOrderInput {
  customer_id: number;
  items: OrderItemInput[];
}

export interface CreatedOrder {
  id: number;
  status: "CREATED" | "CONFIRMED" | "CANCELED";
  total_cents: number;
}

export interface IOrdersRepository {
  createOrder(input: CreateOrderInput): Promise<CreatedOrder>;
  confirmOrder(orderId: number): Promise<{ id: number; status: string; total_cents: number }>;
}
